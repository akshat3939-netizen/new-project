
import React, { useState, useEffect } from 'react';
import { UserProfile, CHAPTERS, AVATARS } from '../types';
import { generateFullMissionContent, getCachedMission } from '../services/geminiService';

interface LifePathProps {
  user: UserProfile;
  onSelectSubtopic: (chapterIdx: number, subtopicIdx: number) => void;
  onOpenLeaderboard: () => void;
  onOpenAchievements: () => void;
  onOpenCharacter: () => void;
}

const LifePath: React.FC<LifePathProps> = ({ 
  user, onSelectSubtopic, onOpenLeaderboard, onOpenAchievements, onOpenCharacter 
}) => {
  const [expandedChapter, setExpandedChapter] = useState<number | null>(user.unlockedLevels - 1);
  const [preloading, setPreloading] = useState<Record<string, boolean>>({});

  // Background pre-loading logic to eliminate wait times
  useEffect(() => {
    const preloadNextMissions = async () => {
      const currentChapter = user.unlockedLevels - 1;
      const chapterData = CHAPTERS[currentChapter];
      if (!chapterData) return;

      for (let j = 0; j < chapterData.subtopics.length; j++) {
        const subtopic = chapterData.subtopics[j];
        const id = `${chapterData.name}_${subtopic}`;
        
        if (!getCachedMission(chapterData.name, subtopic)) {
          setPreloading(prev => ({ ...prev, [id]: true }));
          try {
            await generateFullMissionContent(chapterData.name, subtopic, 'Medium');
          } catch (e) {
            console.error("Preload failed", e);
          } finally {
            setPreloading(prev => ({ ...prev, [id]: false }));
          }
        }
      }
    };

    preloadNextMissions();
  }, [user.unlockedLevels]);

  return (
    <div className="min-h-screen bg-[#EBC16E] relative overflow-x-hidden font-sans">
      {/* Decorative props */}
      <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-[10%] text-6xl float-animation">🔭</div>
        <div className="absolute top-[30%] right-[15%] text-7xl float-animation" style={{ animationDelay: '1s' }}>🪐</div>
        <div className="absolute bottom-[20%] left-[5%] text-5xl float-animation" style={{ animationDelay: '2s' }}>⚡</div>
      </div>

      {/* Top Header */}
      <div className="fixed top-0 left-0 right-0 z-50 p-4 flex justify-between items-start pointer-events-none">
        <div className="flex flex-col gap-2 pointer-events-auto">
          <div className="flex items-center gap-3 bg-white/95 backdrop-blur p-2 pr-6 rounded-full shadow-2xl border-2 border-emerald-500 group">
            <div 
              onClick={onOpenCharacter}
              className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center text-3xl border-2 border-white overflow-hidden shadow-inner cursor-pointer hover:rotate-12 transition-transform"
            >
              {user.avatar}
            </div>
            <div>
              <div className="text-[10px] font-black text-emerald-600 uppercase tracking-tighter">ELITE LEVEL {user.level}</div>
              <div className="font-black text-gray-800 text-lg leading-none">{user.name}</div>
            </div>
          </div>
          <button 
            onClick={onOpenLeaderboard}
            className="bg-[#2D3E50] text-white py-3 px-8 rounded-full flex items-center gap-3 shadow-xl border-2 border-white/20 text-sm font-black transform transition-all hover:scale-110 active:scale-95 hover:bg-[#3d556e]"
          >
            <span className="text-lg">🏆</span> Leaderboard
          </button>
        </div>

        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          <div className="bg-[#2D3E50] text-white p-2 px-4 rounded-full flex items-center gap-3 shadow-xl border-2 border-white/20">
            <span className="text-amber-400 text-2xl drop-shadow-[0_2px_0_rgba(0,0,0,0.5)]">⭐</span>
            <span className="font-black text-xl">{user.stars}</span>
          </div>
          <button className="w-12 h-12 bg-white/20 backdrop-blur rounded-full flex items-center justify-center text-white shadow-xl border-2 border-white/20 hover:rotate-90 transition-transform">
            ⚙️
          </button>
        </div>
      </div>

      {/* App Branding */}
      <div className="pt-32 text-center mb-16 px-4 relative z-10">
        <h1 className="game-font text-9xl text-[#2D3E50] drop-shadow-2xl mb-1 tracking-tighter leading-none">SciMaze</h1>
        <p className="text-[#2D3E50]/60 font-black uppercase tracking-[0.5em] text-[11px] bg-white/20 backdrop-blur-md inline-block px-6 py-2 rounded-full border border-white/30">
          "Making learning fun"
        </p>
      </div>

      {/* The Journey Path */}
      <div className="pb-64 flex flex-col items-center max-w-xl mx-auto relative z-10">
        {CHAPTERS.map((chap, i) => {
          const isChapterLocked = i > user.unlockedLevels - 1;
          const isExpanded = expandedChapter === i;
          
          return (
            <div key={i} className="w-full mb-10 px-6">
              {/* Chapter Card */}
              <button 
                disabled={isChapterLocked}
                onClick={() => setExpandedChapter(isExpanded ? null : i)}
                className={`
                  w-full p-8 rounded-[3rem] border-b-[10px] transition-all flex items-center justify-between group
                  ${isChapterLocked ? 'bg-gray-100 border-gray-200 opacity-60' : isExpanded ? 'bg-emerald-500 border-emerald-700 text-white shadow-3xl scale-105' : 'bg-white border-gray-200 text-[#2D3E50] shadow-2xl hover:translate-y-[-2px]'}
                `}
              >
                <div className="text-left">
                  <span className={`text-[11px] font-black uppercase tracking-[0.2em] block mb-2 ${isExpanded ? 'opacity-60' : 'text-emerald-500'}`}>MODULE {i + 1}</span>
                  <h3 className="text-2xl font-black leading-tight tracking-tight">{chap.name}</h3>
                </div>
                <div className="text-4xl transition-transform group-hover:scale-125">
                  {isChapterLocked ? '🔒' : isExpanded ? '🔓' : '🚀'}
                </div>
              </button>

              {/* Subtopic Steps */}
              {isExpanded && !isChapterLocked && (
                <div className="mt-8 space-y-4 pl-6 border-l-[6px] border-emerald-400/40 animate-in fade-in slide-in-from-top-6 duration-500">
                  {chap.subtopics.map((sub, j) => {
                    const progress = user.progress[i]?.[j] || { summaryDone: false, quizStars: 0 };
                    const id = `${chap.name}_${sub}`;
                    const isReady = !!getCachedMission(chap.name, sub);
                    
                    return (
                      <button
                        key={j}
                        onClick={() => onSelectSubtopic(i, j)}
                        className="w-full bg-white/60 backdrop-blur-md hover:bg-white p-6 rounded-[2rem] flex items-center justify-between border-2 border-white shadow-lg transition-all active:scale-95 group/sub"
                      >
                        <div className="flex items-center gap-5">
                          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg transition-colors relative ${progress.quizStars > 0 ? 'bg-emerald-400 text-white shadow-lg' : 'bg-gray-100 text-gray-400 shadow-inner'}`}>
                            {j + 1}
                            {!isReady && !isChapterLocked && (
                              <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full animate-pulse border-2 border-white"></div>
                            )}
                          </div>
                          <div className="text-left">
                            <span className="font-black text-gray-700 text-lg tracking-tight group-hover/sub:text-emerald-600 transition-colors block">{sub}</span>
                            {!isReady && <span className="text-[9px] font-bold text-amber-600 uppercase">Calibrating...</span>}
                          </div>
                        </div>
                        <div className="flex gap-1.5 bg-black/5 p-2 rounded-2xl">
                          {[1, 2, 3].map(s => (
                            <span key={s} className={`text-xl drop-shadow-sm ${s <= progress.quizStars ? 'text-amber-400 scale-110' : 'text-gray-300 opacity-30'}`}>⭐</span>
                          ))}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer Nav */}
      <div className="fixed bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-[#2D3E50]/40 to-transparent pointer-events-none z-50">
        <div className="max-w-md mx-auto bg-[#2D3E50] p-3 rounded-[3rem] flex justify-around shadow-[0_20px_40px_rgba(0,0,0,0.4)] border-4 border-white/20 pointer-events-auto overflow-hidden">
          <button onClick={onOpenCharacter} className="flex-1 py-4 text-4xl hover:bg-white/10 rounded-3xl transition-all hover:scale-110" title="Character">👕</button>
          <button onClick={() => setExpandedChapter(user.unlockedLevels-1)} className="flex-1 py-4 text-4xl bg-emerald-500 rounded-3xl shadow-inner text-white ring-8 ring-emerald-500/30 scale-110" title="Path">🗺️</button>
          <button onClick={onOpenAchievements} className="flex-1 py-4 text-4xl hover:bg-white/10 rounded-3xl transition-all hover:scale-110" title="Achievements">🏅</button>
        </div>
      </div>
    </div>
  );
};

export default LifePath;
