
import React, { useState, useEffect } from 'react';
import { UserProfile, Question, Difficulty, CHAPTERS, XP_PER_LEVEL, AVATARS } from '../types';
import Signup from './Signup';
import Tutorial from './Tutorial';
import LifePath from './LifePath';
import MissionDashboard from './MissionDashboard';
import QuizizzView from './QuizizzView';

const MazeGame: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('science_maze_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [activeChapterIdx, setActiveChapterIdx] = useState<number | null>(null);
  const [activeSubtopicIdx, setActiveSubtopicIdx] = useState<number | null>(null);
  const [activeQuestions, setActiveQuestions] = useState<Question[] | null>(null);
  const [view, setView] = useState<'path' | 'dashboard' | 'quiz' | 'leaderboard' | 'character' | 'achievements'>('path');

  useEffect(() => {
    if (user) {
      localStorage.setItem('science_maze_user', JSON.stringify(user));
      updateLeaderboard(user);
    }
  }, [user]);

  const updateLeaderboard = (currentUser: UserProfile) => {
    const saved = localStorage.getItem('scimaze_global_leaderboard');
    let board = saved ? JSON.parse(saved) : [
      { name: "Vikram R.", level: 10, stars: 90, avatar: "👨‍🔬" },
      { name: "Ananya P.", level: 8, stars: 72, avatar: "👩‍🚀" },
      { name: "Siddharth", level: 6, stars: 54, avatar: "👨‍✈️" },
      { name: "Ishani", level: 4, stars: 36, avatar: "🧙‍♀️" },
      { name: "Kabir", level: 2, stars: 18, avatar: "👱" }
    ];

    const myIdx = board.findIndex((p: any) => p.name === currentUser.name || p.isMe);
    if (myIdx !== -1) {
      board[myIdx] = { name: currentUser.name, level: currentUser.level, stars: currentUser.stars, avatar: currentUser.avatar, isMe: true };
    } else {
      board.push({ name: currentUser.name, level: currentUser.level, stars: currentUser.stars, avatar: currentUser.avatar, isMe: true });
    }

    board.sort((a: any, b: any) => b.stars - a.stars);
    localStorage.setItem('scimaze_global_leaderboard', JSON.stringify(board));
  };

  const handleSelectSubtopic = (chapterIdx: number, subtopicIdx: number) => {
    setActiveChapterIdx(chapterIdx);
    setActiveSubtopicIdx(subtopicIdx);
    setView('dashboard');
  };

  const handleCompleteSummary = () => {
    if (activeChapterIdx === null || activeSubtopicIdx === null) return;
    setUser(prev => {
      if (!prev) return null;
      const chapterProgress = prev.progress[activeChapterIdx] || {};
      const subtopicProgress = chapterProgress[activeSubtopicIdx] || { summaryDone: false, quizStars: 0 };
      
      const newAchievements = [...prev.achievements];
      const aIdx = newAchievements.findIndex(a => a.id === 'first_steps');
      if (aIdx !== -1 && !newAchievements[aIdx].unlocked) {
        newAchievements[aIdx].unlocked = true;
      }

      return {
        ...prev,
        achievements: newAchievements,
        progress: {
          ...prev.progress,
          [activeChapterIdx]: {
            ...chapterProgress,
            [activeSubtopicIdx]: { ...subtopicProgress, summaryDone: true }
          }
        }
      };
    });
  };

  const handleStartQuiz = (qs: Question[]) => {
    setActiveQuestions(qs);
    setView('quiz');
  };

  const handleFinishQuiz = (stars: number, wrongAnswers: number) => {
    if (activeChapterIdx === null || activeSubtopicIdx === null) return;
    
    setUser(prev => {
      if (!prev) return null;
      
      const chapterProgress = prev.progress[activeChapterIdx] || {};
      const subtopicProgress = chapterProgress[activeSubtopicIdx] || { summaryDone: true, quizStars: 0 };
      const oldStars = subtopicProgress.quizStars;
      const starGain = Math.max(0, stars - oldStars);

      let newXP = prev.xp + (stars * 75);
      let newLevel = prev.level;
      if (newXP >= XP_PER_LEVEL) {
        newXP -= XP_PER_LEVEL;
        newLevel += 1;
      }

      const newAchievements = [...prev.achievements];
      if (stars === 3) {
        const idx = newAchievements.findIndex(a => a.id === 'quiz_master');
        if (idx !== -1) newAchievements[idx].unlocked = true;
      }
      if (wrongAnswers === 0 && stars > 0) {
        const idx = newAchievements.findIndex(a => a.id === 'speed_demon');
        if (idx !== -1) newAchievements[idx].unlocked = true;
      }
      if (newLevel >= 5) {
        const idx = newAchievements.findIndex(a => a.id === 'level_5');
        if (idx !== -1) newAchievements[idx].unlocked = true;
      }

      const subtopicsInChapter = CHAPTERS[activeChapterIdx].subtopics.length;
      let newUnlocked = prev.unlockedLevels;
      if (oldStars === 0 && stars > 0 && activeSubtopicIdx === subtopicsInChapter - 1 && activeChapterIdx === prev.unlockedLevels - 1) {
        newUnlocked = Math.min(CHAPTERS.length, prev.unlockedLevels + 1);
      }

      return {
        ...prev,
        xp: newXP,
        level: newLevel,
        stars: prev.stars + starGain,
        unlockedLevels: newUnlocked,
        achievements: newAchievements,
        progress: {
          ...prev.progress,
          [activeChapterIdx]: {
            ...chapterProgress,
            [activeSubtopicIdx]: { ...subtopicProgress, quizStars: Math.max(oldStars, stars) }
          }
        }
      };
    });

    setView('path');
    setActiveChapterIdx(null);
    setActiveSubtopicIdx(null);
    setActiveQuestions(null);
  };

  if (!user) return <Signup onComplete={setUser} />;
  
  if (!user.hasSeenTutorial) {
    return <Tutorial onComplete={() => setUser(prev => prev ? ({ ...prev, hasSeenTutorial: true }) : null)} />;
  }

  const renderLeaderboard = () => {
    const saved = localStorage.getItem('scimaze_global_leaderboard');
    const board = saved ? JSON.parse(saved) : [];

    return (
      <div className="fixed inset-0 z-[100] bg-[#1a2b3c] flex flex-col items-center justify-center p-8 animate-in slide-in-from-bottom duration-500">
        <div className="w-full max-w-lg bg-white rounded-[3rem] p-8 shadow-2xl relative border-4 border-amber-500">
          <div className="text-center mb-10">
            <div className="text-6xl mb-2">🏆</div>
            <h2 className="game-font text-5xl text-gray-800 tracking-tight">Arena Standings</h2>
            <p className="text-amber-600 font-black uppercase tracking-widest text-[10px] mt-1 italic">Real Competitors</p>
          </div>
          
          <div className="space-y-4 mb-10 max-h-[40vh] overflow-y-auto px-2 custom-scrollbar">
            {board.map((player: any, i: number) => (
              <div key={i} className={`flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${player.isMe ? 'bg-amber-50 border-amber-500 scale-105 shadow-md' : 'bg-gray-50 border-gray-100'}`}>
                <div className={`w-10 h-10 flex items-center justify-center font-black text-xl ${i < 3 ? 'text-amber-500' : 'text-gray-400'}`}>#{i+1}</div>
                <div className="text-3xl">{player.avatar}</div>
                <div className="flex-1">
                  <div className="font-black text-gray-800 leading-none flex items-center gap-2">
                    {player.name}
                    {player.isMe && <span className="bg-amber-500 text-white text-[8px] px-1.5 py-0.5 rounded-full">YOU</span>}
                  </div>
                  <div className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-tighter">LVL {player.level} | MASTERY</div>
                </div>
                <div className="flex items-center gap-1 font-black text-amber-600 text-lg">
                  ⭐ {player.stars}
                </div>
              </div>
            ))}
          </div>

          <button 
            onClick={() => setView('path')}
            className="w-full py-6 bg-gray-900 text-white rounded-[2rem] font-black text-xl shadow-[0_10px_0_#000] active:translate-y-2 active:shadow-none transition-all uppercase"
          >
            Close Arena 🛡️
          </button>
        </div>
      </div>
    );
  };

  const renderAchievements = () => (
    <div className="fixed inset-0 z-[100] bg-[#1a2b3c] flex flex-col items-center justify-center p-8 animate-in zoom-in duration-500">
      <div className="w-full max-w-lg bg-white rounded-[3rem] p-10 shadow-2xl border-4 border-emerald-500">
        <div className="text-center mb-8">
          <div className="text-6xl mb-2">🏅</div>
          <h2 className="game-font text-5xl text-gray-800">My Trophies</h2>
          <p className="text-emerald-600 font-black uppercase tracking-widest text-[10px]">Your journey is legendary</p>
        </div>

        <div className="grid grid-cols-1 gap-4 mb-10">
          {user.achievements.map((ach) => (
            <div key={ach.id} className={`flex items-center gap-6 p-5 rounded-3xl border-2 transition-all ${ach.unlocked ? 'bg-emerald-50 border-emerald-500' : 'bg-gray-50 border-gray-100 opacity-40 grayscale'}`}>
              <div className="text-4xl">{ach.emoji}</div>
              <div className="text-left">
                <div className="font-black text-gray-800 text-lg leading-tight">{ach.title}</div>
                <div className="text-xs text-gray-500 font-medium">{ach.description}</div>
              </div>
              {ach.unlocked && <div className="ml-auto text-emerald-500 text-2xl font-black">✓</div>}
            </div>
          ))}
        </div>

        <button 
          onClick={() => setView('path')}
          className="w-full py-6 bg-emerald-500 text-white rounded-[2rem] font-black text-xl shadow-[0_10px_0_#065f46] active:translate-y-2 active:shadow-none transition-all uppercase"
        >
          Keep Questing 🧬
        </button>
      </div>
    </div>
  );

  const renderCharacter = () => (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-lg bg-white rounded-[3rem] p-10 shadow-2xl border-4 border-blue-500">
        <div className="text-center mb-10">
          <div className="w-24 h-24 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center text-6xl shadow-inner border-2 border-white">
            {user.avatar}
          </div>
          <h2 className="game-font text-5xl text-gray-800">Switch Identity</h2>
          <p className="text-blue-600 font-black uppercase tracking-widest text-[10px]">Change your tactical appearance</p>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-10">
          {AVATARS.map((av) => (
            <button
              key={av.id}
              onClick={() => setUser(prev => prev ? ({ ...prev, avatar: av.face }) : null)}
              className={`p-4 rounded-3xl border-4 transition-all flex flex-col items-center gap-2 ${user.avatar === av.face ? 'border-blue-500 bg-blue-50 scale-110' : 'border-gray-100 bg-gray-50 hover:border-blue-200'}`}
            >
              <div className="text-4xl">{av.face}</div>
              <div className="text-[8px] font-black text-gray-400 uppercase leading-none">{av.label}</div>
            </button>
          ))}
        </div>

        <button 
          onClick={() => setView('path')}
          className="w-full py-6 bg-blue-600 text-white rounded-[2rem] font-black text-xl shadow-[0_10px_0_#1e40af] active:translate-y-2 active:shadow-none transition-all uppercase"
        >
          Confirm Switch 👕
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      <LifePath 
        user={user} 
        onSelectSubtopic={handleSelectSubtopic}
        onOpenLeaderboard={() => setView('leaderboard')}
        onOpenAchievements={() => setView('achievements')}
        onOpenCharacter={() => setView('character')}
      />
      
      {view === 'dashboard' && activeChapterIdx !== null && activeSubtopicIdx !== null && (
        <MissionDashboard 
          chapter={CHAPTERS[activeChapterIdx].name}
          subtopic={CHAPTERS[activeChapterIdx].subtopics[activeSubtopicIdx]}
          difficulty={activeChapterIdx > 3 ? 'Hard' : activeChapterIdx > 1 ? 'Medium' : 'Easy'}
          onClose={() => setView('path')}
          onCompleteSummary={handleCompleteSummary}
          isSummaryDone={user.progress[activeChapterIdx]?.[activeSubtopicIdx]?.summaryDone || false}
          onStartQuiz={handleStartQuiz}
        />
      )}

      {view === 'quiz' && activeQuestions && (
        <QuizizzView 
          questions={activeQuestions}
          onFinish={handleFinishQuiz}
        />
      )}

      {view === 'leaderboard' && renderLeaderboard()}
      {view === 'character' && renderCharacter()}
      {view === 'achievements' && renderAchievements()}
    </div>
  );
};

export default MazeGame;
