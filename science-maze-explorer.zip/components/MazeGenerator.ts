
import { CellType } from '../types';

export const generateMaze = (size: number, puzzleCount: number): CellType[][] => {
  const maze: CellType[][] = Array(size).fill(null).map(() => Array(size).fill('wall'));

  const stack: [number, number][] = [];
  const startX = 1, startY = 1;
  maze[startY][startX] = 'path';
  stack.push([startX, startY]);

  while (stack.length > 0) {
    const [x, y] = stack[stack.length - 1];
    const neighbors: [number, number][] = [];

    const directions = [[0, 2], [0, -2], [2, 0], [-2, 0]];
    for (const [dx, dy] of directions) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx > 0 && nx < size - 1 && ny > 0 && ny < size - 1 && maze[ny][nx] === 'wall') {
        neighbors.push([nx, ny]);
      }
    }

    if (neighbors.length > 0) {
      const [nx, ny] = neighbors[Math.floor(Math.random() * neighbors.length)];
      maze[ny][nx] = 'path';
      maze[y + (ny - y) / 2][x + (nx - x) / 2] = 'path';
      stack.push([nx, ny]);
    } else {
      stack.pop();
    }
  }

  // Set start and end
  maze[1][1] = 'start';
  maze[size - 2][size - 2] = 'end';

  // Add puzzles
  let placedPuzzles = 0;
  while (placedPuzzles < puzzleCount) {
    const rx = Math.floor(Math.random() * (size - 2)) + 1;
    const ry = Math.floor(Math.random() * (size - 2)) + 1;
    if (maze[ry][rx] === 'path') {
      maze[ry][rx] = 'puzzle';
      placedPuzzles++;
    }
  }

  return maze;
};
