
import React, { useState, useEffect, useRef } from 'react';
import { Summary, Question, Difficulty } from '../types';
import { generateFullMissionContent, generateBriefingAudio, getCachedMission } from '../services/geminiService';

interface MissionDashboardProps {
  chapter: string;
  subtopic: string;
  difficulty: Difficulty;
  onClose: () => void;
  onStartQuiz: (questions: Question[]) => void;
  onCompleteSummary: () => void;
  isSummaryDone: boolean;
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const MissionDashboard: React.FC<MissionDashboardProps> = ({ 
  chapter, subtopic, difficulty, onClose, onStartQuiz, onCompleteSummary, isSummaryDone 
}) => {
  const [loading, setLoading] = useState(true);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [prefetchedQuiz, setPrefetchedQuiz] = useState<Question[] | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    const initMission = async () => {
      // Check cache first for instant load
      const cached = getCachedMission(chapter, subtopic);
      if (cached) {
        setSummary(cached.summary);
        setPrefetchedQuiz(cached.quiz);
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const { summary: s, quiz: q } = await generateFullMissionContent(chapter, subtopic, difficulty);
        setSummary(s);
        setPrefetchedQuiz(q);
      } catch (err) {
        console.error("Mission loading failed:", err);
      } finally {
        setLoading(false);
      }
    };
    initMission();

    return () => {
      if (sourceRef.current) {
        try { sourceRef.current.stop(); } catch(e) {}
      }
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, [chapter, subtopic, difficulty]);

  const playAIExplanation = async () => {
    if (!summary) return;
    if (isPlaying) {
      try { sourceRef.current?.stop(); } catch(e) {}
      setIsPlaying(false);
      return;
    }

    setIsAudioLoading(true);
    try {
      const fullText = `Namaste! Let's master ${subtopic}. The key facts are: ${summary.content.join(". ")}. Don't forget these terms: ${summary.key_terms.join(", ")}. Are you ready for the board challenge?`;
      const base64Audio = await generateBriefingAudio(fullText);
      
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const audioData = decode(base64Audio);
      const audioBuffer = await decodeAudioData(audioData, audioContextRef.current, 24000, 1);
      
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      source.onended = () => {
        setIsPlaying(false);
        onCompleteSummary();
      };
      
      sourceRef.current = source;
      source.start();
      setIsPlaying(true);
    } catch (err) {
      console.error("Audio briefing failed:", err);
    } finally {
      setIsAudioLoading(false);
    }
  };

  const handleStartQuiz = () => {
    if (prefetchedQuiz) {
      onStartQuiz(prefetchedQuiz);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="bg-white rounded-[3.5rem] w-full max-w-xl overflow-hidden shadow-[0_32px_0_rgba(0,0,0,0.2)] relative border-4 border-emerald-500 animate-in zoom-in duration-300">
        <button onClick={onClose} className="absolute top-6 right-6 w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center font-bold text-gray-500 hover:bg-gray-200 transition-colors z-10 shadow-inner">✕</button>
        
        <div className="bg-emerald-500 p-10 text-white relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-[10px] font-black uppercase tracking-[0.3em] opacity-80 mb-1">MISSION DATA</h2>
            <h3 className="game-font text-4xl leading-tight">{subtopic}</h3>
            <p className="text-xs font-bold opacity-60 mt-1 uppercase tracking-widest">{chapter}</p>
          </div>
          <div className="absolute top-0 right-0 p-4 text-8xl opacity-10 transform translate-x-4 -translate-y-4 animate-pulse">🧪</div>
        </div>

        <div className="p-10">
          {loading ? (
            <div className="py-16 flex flex-col items-center">
              <div className="w-14 h-14 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-6"></div>
              <p className="game-font text-emerald-600 text-xl animate-pulse">Syncing Lab Data...</p>
            </div>
          ) : summary && (
            <div className="space-y-10">
              <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 p-8 rounded-[3rem] border-2 border-emerald-200 shadow-inner flex flex-col items-center text-center group">
                <div className="w-28 h-28 bg-white rounded-full shadow-2xl flex items-center justify-center text-6xl mb-6 float-animation border-4 border-emerald-400 group-hover:scale-110 transition-transform">
                  🤖
                </div>
                <h4 className="game-font text-3xl text-emerald-800 mb-2">Professor Sci</h4>
                <p className="text-gray-500 mb-8 font-bold text-sm tracking-tight px-4 leading-relaxed">The Professor has prepared an instant briefing for you.</p>
                
                <button
                  onClick={playAIExplanation}
                  disabled={isAudioLoading}
                  className={`px-12 py-5 rounded-[2.5rem] font-black transition-all transform active:scale-95 flex items-center gap-4 text-xl shadow-[0_8px_0_rgba(0,0,0,0.1)] ${
                    isAudioLoading ? 'bg-gray-200 text-gray-400 cursor-wait' :
                    isPlaying ? 'bg-rose-500 text-white animate-pulse' : 'bg-emerald-500 text-white hover:bg-emerald-600'
                  }`}
                >
                  {isAudioLoading ? (
                    <><span className="w-6 h-6 border-4 border-gray-400 border-t-transparent rounded-full animate-spin"></span> SYNCING...</>
                  ) : isPlaying ? (
                    <>⏹ STOP SESSION</>
                  ) : (
                    <>🔊 HEAR BRIEFING</>
                  )}
                </button>
              </div>

              <button
                disabled={!isSummaryDone}
                onClick={handleStartQuiz}
                className={`w-full py-6 rounded-[2.5rem] font-black shadow-[0_12px_0_#000] transition-all transform active:translate-y-2 active:shadow-none text-2xl uppercase tracking-widest ${
                  isSummaryDone ? 'bg-gray-900 text-white hover:bg-black' : 'bg-gray-100 text-gray-300 cursor-not-allowed opacity-50'
                }`}
              >
                Launch Challenge ⚔️
              </button>
              
              {!isSummaryDone && (
                <p className="text-center text-[10px] font-black text-amber-600 uppercase tracking-[0.3em] animate-bounce">
                  Finish briefing to unlock challenge
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MissionDashboard;
