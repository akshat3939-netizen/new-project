
import React, { useState } from 'react';
import { Question } from '../types';

interface QuestionModalProps {
  question: Question;
  onAnswer: (isCorrect: boolean) => void;
}

const QuestionModal: React.FC<QuestionModalProps> = ({ question, onAnswer }) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const handleSubmit = () => {
    if (!selectedOption) return;
    const correct = selectedOption === question.correct_answer;
    setIsCorrect(correct);
    setHasSubmitted(true);
  };

  const handleContinue = () => {
    onAnswer(isCorrect);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden transform transition-all">
        {/* Header */}
        <div className="bg-emerald-500 p-6 text-white text-center">
          <h2 className="game-font text-2xl">Puzzle Challenge!</h2>
          <div className="flex justify-center gap-2 mt-2">
            <span className="bg-emerald-600/50 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              {question.difficulty}
            </span>
            <span className="bg-emerald-600/50 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              {question.question_type}
            </span>
          </div>
        </div>

        <div className="p-8">
          <p className="text-xl font-bold text-gray-800 mb-6 leading-relaxed">
            {question.question}
          </p>

          {!hasSubmitted ? (
            <div className="space-y-3">
              {question.options && question.options.length > 0 ? (
                question.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedOption(opt)}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 ${
                      selectedOption === opt
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700 font-bold'
                        : 'border-gray-100 hover:border-emerald-200 hover:bg-emerald-50/30'
                    }`}
                  >
                    <span className="inline-block w-8 font-bold text-emerald-400">{String.fromCharCode(65 + i)}.</span>
                    {opt}
                  </button>
                ))
              ) : (
                <div className="space-y-4">
                  <input
                    type="text"
                    onChange={(e) => setSelectedOption(e.target.value)}
                    placeholder="Type your answer here..."
                    className="w-full p-4 rounded-xl border-2 border-gray-100 focus:border-emerald-500 outline-none"
                  />
                  <p className="text-sm text-gray-500">Hint: {question.hint || "Think about the concepts we studied!"}</p>
                </div>
              )}

              <div className="flex gap-4 mt-8">
                {question.hint && !showHint && (
                  <button 
                    onClick={() => setShowHint(true)}
                    className="flex-1 py-4 text-emerald-600 font-bold border-2 border-emerald-100 rounded-2xl hover:bg-emerald-50"
                  >
                    Need a Hint?
                  </button>
                )}
                <button
                  onClick={handleSubmit}
                  disabled={!selectedOption}
                  className={`flex-[2] py-4 rounded-2xl font-bold text-white shadow-lg transform transition-transform active:scale-95 ${
                    selectedOption ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-gray-300 cursor-not-allowed'
                  }`}
                >
                  Unlock Gate
                </button>
              </div>
              {showHint && (
                <p className="mt-4 p-3 bg-amber-50 text-amber-700 rounded-lg text-sm italic">
                   💡 {question.hint}
                </p>
              )}
            </div>
          ) : (
            <div className={`text-center space-y-4 ${isCorrect ? 'text-emerald-600' : 'text-rose-600'}`}>
              <div className="flex flex-col items-center">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center text-4xl mb-4 ${isCorrect ? 'bg-emerald-100' : 'bg-rose-100'}`}>
                  {isCorrect ? '✨' : '❌'}
                </div>
                <h3 className="text-3xl font-black">{isCorrect ? 'Brilliant!' : 'Oops!'}</h3>
                <p className="text-gray-600 mt-2 font-medium">
                  {isCorrect ? `You earned ${question.points} points!` : 'The gate remains locked for now.'}
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-2xl mt-6 text-left">
                <p className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-1">Quick Explanation</p>
                <p className="text-gray-700 leading-relaxed">{question.explanation}</p>
                {!isCorrect && (
                  <p className="mt-4 pt-4 border-t border-gray-200 text-emerald-600 font-bold">
                    Correct Answer: <span className="text-gray-900 font-normal">{question.correct_answer}</span>
                  </p>
                )}
              </div>

              <button
                onClick={handleContinue}
                className="w-full mt-8 py-4 bg-gray-900 text-white rounded-2xl font-bold shadow-xl hover:bg-gray-800 transform transition-transform active:scale-95"
              >
                Continue Adventure
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestionModal;
