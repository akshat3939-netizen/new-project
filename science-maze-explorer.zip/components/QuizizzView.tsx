
import React, { useState, useEffect, useRef } from 'react';
import { Question } from '../types';

interface QuizizzViewProps {
  questions: Question[];
  onFinish: (stars: number, wrongAnswers: number) => void;
}

const COLORS = ['bg-purple-500', 'bg-blue-500', 'bg-orange-500', 'bg-teal-500'];

const QuizizzView: React.FC<QuizizzViewProps> = ({ questions, onFinish }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [timeLeft, setTimeLeft] = useState(25);
  const [selected, setSelected] = useState<string | null>(null);
  const [isShowingFeedback, setIsShowingFeedback] = useState(false);
  
  const audioCtxRef = useRef<AudioContext | null>(null);

  const currentQ = questions[currentIndex];

  useEffect(() => {
    audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    return () => {
      audioCtxRef.current?.close();
    };
  }, []);

  const playSfx = (type: 'correct' | 'wrong') => {
    if (!audioCtxRef.current) return;
    const osc = audioCtxRef.current.createOscillator();
    const gain = audioCtxRef.current.createGain();
    
    osc.connect(gain);
    gain.connect(audioCtxRef.current.destination);
    
    const now = audioCtxRef.current.currentTime;
    
    if (type === 'correct') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    } else {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.linearRampToValueAtTime(100, now + 0.2);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.linearRampToValueAtTime(0.01, now + 0.4);
      osc.start(now);
      osc.stop(now + 0.4);
    }
  };

  useEffect(() => {
    if (isShowingFeedback || timeLeft === 0) return;
    const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, isShowingFeedback]);

  useEffect(() => {
    if (timeLeft === 0 && !isShowingFeedback) {
      handleAnswer('');
    }
  }, [timeLeft]);

  const handleAnswer = (ans: string) => {
    setSelected(ans);
    setIsShowingFeedback(true);
    const correct = ans === currentQ.correct_answer;
    
    if (correct) {
      setScore(s => s + 1);
      playSfx('correct');
    } else {
      setWrongAnswers(w => w + 1);
      playSfx('wrong');
    }

    setTimeout(() => {
      if (currentIndex < questions.length - 1) {
        setCurrentIndex(i => i + 1);
        setTimeLeft(25);
        setSelected(null);
        setIsShowingFeedback(false);
      } else {
        const finalStars = Math.ceil(( (score + (correct ? 1 : 0)) / questions.length) * 3) || 1;
        onFinish(finalStars, wrongAnswers + (correct ? 0 : 1));
      }
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[70] bg-[#1e0524] flex flex-col p-6 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 text-9xl">🔬</div>
        <div className="absolute bottom-10 right-10 text-9xl">🧪</div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[20rem] font-black text-white/5">EXAM</div>
      </div>

      {/* Top Bar */}
      <div className="relative flex items-center gap-4 mb-8">
        <div className="flex-1 h-4 bg-white/10 rounded-full overflow-hidden border border-white/10">
          <div 
            className="h-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all duration-1000 shadow-[0_0_15px_rgba(245,158,11,0.5)]" 
            style={{ width: `${(timeLeft / 25) * 100}%` }}
          />
        </div>
        <div className="w-16 h-16 bg-white/10 backdrop-blur rounded-2xl flex items-center justify-center text-white font-black text-2xl border border-white/20 shadow-xl">
          {timeLeft}
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full relative">
        {/* Question Header */}
        <div className="bg-white/5 backdrop-blur-md p-10 rounded-[3rem] w-full mb-10 text-center shadow-2xl border-2 border-white/10">
          <div className="flex justify-center gap-2 mb-6">
            {questions.map((_, i) => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-500 ${i === currentIndex ? 'w-12 bg-amber-400' : i < currentIndex ? 'w-4 bg-emerald-400' : 'w-4 bg-white/10'}`}
              />
            ))}
          </div>
          <div className="text-[10px] font-black text-amber-400 uppercase tracking-[0.4em] mb-4">
            BOARD EXAM CHALLENGE {currentIndex + 1} / {questions.length}
          </div>
          <h2 className="text-white text-3xl font-black leading-tight drop-shadow-lg">
            {currentQ.question}
          </h2>
        </div>

        {/* Options Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
          {currentQ.options?.map((opt, i) => {
            const isCorrect = opt === currentQ.correct_answer;
            const isSelected = selected === opt;
            const isWrong = isSelected && !isCorrect;
            
            return (
              <button
                key={i}
                disabled={isShowingFeedback}
                onClick={() => handleAnswer(opt)}
                className={`
                  relative min-h-[110px] rounded-3xl p-6 text-white text-xl font-black shadow-2xl transition-all transform active:scale-95 text-left flex items-center gap-6 overflow-hidden border-b-[8px]
                  ${isShowingFeedback 
                    ? (isCorrect ? 'bg-emerald-500 border-emerald-700 scale-105 z-10' : isWrong ? 'bg-rose-500 border-rose-700 shake' : 'bg-gray-800 border-gray-900 opacity-20')
                    : `${COLORS[i]} border-black/20 hover:brightness-110 hover:-translate-y-1`
                  }
                `}
              >
                <div className="w-12 h-12 rounded-xl bg-black/20 flex items-center justify-center shrink-0 border border-white/10 text-2xl">
                  {['▲', '●', '■', '✦'][i]}
                </div>
                <span className="leading-tight flex-1">{opt}</span>
                {isShowingFeedback && isCorrect && <span className="text-4xl animate-bounce">✨</span>}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-8 flex justify-center">
        <p className="text-white/30 font-black uppercase tracking-[0.3em] text-[10px]">Thinking determines your score</p>
      </div>
    </div>
  );
};

export default QuizizzView;
