
import React, { useState } from 'react';
import { UserProfile, AVATARS, INITIAL_ACHIEVEMENTS } from '../types';

interface SignupProps {
  onComplete: (user: UserProfile) => void;
}

const Signup: React.FC<SignupProps> = ({ onComplete }) => {
  const [name, setName] = useState('');
  const [selectedIdx, setSelectedIdx] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    onComplete({
      name,
      avatar: AVATARS[selectedIdx].face,
      level: 1,
      xp: 0,
      stars: 0,
      unlockedLevels: 1,
      hasSeenTutorial: false,
      achievements: JSON.parse(JSON.stringify(INITIAL_ACHIEVEMENTS)),
      progress: {}
    });
  };

  return (
    <div className="min-h-screen bg-[#EBC16E] flex items-center justify-center p-6 font-sans relative overflow-hidden">
      {/* Decorative patterns */}
      <div className="absolute inset-0 opacity-10 pointer-events-none grid grid-cols-12 gap-4 -rotate-12 scale-125">
         {Array(48).fill(0).map((_, i) => (
           <div key={i} className="text-4xl">{['🧪','🧬','🔬','🪐','⚡'][i % 5]}</div>
         ))}
      </div>

      <div className="bg-white rounded-[4rem] shadow-[0_24px_0_#d97706] p-12 max-w-2xl w-full border-4 border-amber-600 relative z-10">
        <div className="text-center mb-10">
          <div className="inline-block px-4 py-1 bg-amber-100 rounded-full text-amber-600 font-black text-[10px] uppercase tracking-widest mb-4">
            OFFICIAL CLASS 8 PORTAL
          </div>
          <h1 className="game-font text-8xl text-amber-600 mb-2 drop-shadow-sm tracking-tight">SciMaze</h1>
          <p className="text-gray-400 font-black italic tracking-widest text-lg">"Making learning fun"</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-10">
          <div>
            <label className="block text-xs font-black text-amber-600 uppercase tracking-[0.3em] mb-4 ml-4">ENTER PLAYER INITIALS</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="YOUR NAME..."
              className="w-full p-8 bg-gray-50 border-4 border-gray-100 rounded-[3rem] text-2xl font-black text-center focus:border-amber-500 focus:bg-white outline-none transition-all shadow-inner placeholder:text-gray-200"
              required
              maxLength={15}
            />
          </div>

          <div>
            <label className="block text-xs font-black text-amber-600 uppercase tracking-[0.3em] mb-4 ml-4">SELECT YOUR HERO</label>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {AVATARS.map((av, idx) => (
                <button
                  key={av.id}
                  type="button"
                  onClick={() => setSelectedIdx(idx)}
                  className={`flex flex-col items-center p-4 rounded-[2rem] border-4 transition-all transform ${
                    selectedIdx === idx 
                    ? 'border-amber-500 bg-amber-50 scale-110 shadow-xl' 
                    : 'border-transparent bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <span className="text-5xl mb-1">{av.face}</span>
                  <span className={`text-[9px] font-black uppercase text-center leading-tight ${selectedIdx === idx ? 'text-amber-600' : 'text-gray-400'}`}>
                    {av.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={!name.trim()}
            className="w-full py-8 bg-gray-900 text-white rounded-[3rem] font-black text-3xl shadow-[0_15px_0_#000] hover:translate-y-1 hover:shadow-[0_8px_0_#000] active:translate-y-3 active:shadow-none transition-all uppercase tracking-[0.2em]"
          >
            Launch Lab 🚀
          </button>
        </form>
      </div>
    </div>
  );
};

export default Signup;
