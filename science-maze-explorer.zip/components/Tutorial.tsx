
import React, { useState } from 'react';

const STEPS = [
  {
    title: "Welcome, Explorer!",
    text: "This is your Science Life. You'll travel through NCERT chapters to become a Master Scientist.",
    emoji: "🚀"
  },
  {
    title: "The Maze",
    text: "Use your arrow keys or the controls to move. Find the Golden Trophy 🏆 to complete the level.",
    emoji: "🗺️"
  },
  {
    title: "Science Puzzles",
    text: "The path is blocked by Puzzles 🧩. Solve them correctly to unlock the gate and earn XP!",
    emoji: "🧪"
  },
  {
    title: "Life & Energy",
    text: "Be careful! Wrong answers cost you ❤️. Lose all three and the mission fails.",
    emoji: "⚡"
  }
];

interface TutorialProps {
  onComplete: () => void;
}

const Tutorial: React.FC<TutorialProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const next = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(s => s + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-900/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
      <div className="bg-white rounded-[2.5rem] p-10 max-w-lg w-full text-center shadow-2xl transform transition-all animate-in zoom-in duration-300">
        <div className="text-7xl mb-6 animate-bounce">{STEPS[currentStep].emoji}</div>
        <h2 className="game-font text-3xl text-emerald-600 mb-4">{STEPS[currentStep].title}</h2>
        <p className="text-gray-600 text-lg leading-relaxed mb-8">
          {STEPS[currentStep].text}
        </p>
        <div className="flex flex-col gap-3">
          <button
            onClick={next}
            className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black text-xl shadow-lg hover:bg-emerald-600 active:scale-95 transition-all"
          >
            {currentStep === STEPS.length - 1 ? "Let's Play!" : "Next Tip"}
          </button>
          <div className="flex justify-center gap-2 mt-4">
            {STEPS.map((_, i) => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-300 ${i === currentStep ? 'w-8 bg-emerald-500' : 'w-2 bg-gray-200'}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tutorial;
