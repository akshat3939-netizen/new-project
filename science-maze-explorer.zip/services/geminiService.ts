
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Question, Difficulty, Summary } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const CACHE_KEY = 'scimaze_content_cache';

interface CacheData {
  summary: Summary;
  quiz: Question[];
  timestamp: number;
}

const getCache = (): Record<string, CacheData> => {
  const data = localStorage.getItem(CACHE_KEY);
  return data ? JSON.parse(data) : {};
};

const setCache = (id: string, summary: Summary, quiz: Question[]) => {
  const cache = getCache();
  cache[id] = { summary, quiz, timestamp: Date.now() };
  localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
};

export const getCachedMission = (chapter: string, subtopic: string) => {
  const id = `${chapter}_${subtopic}`;
  return getCache()[id];
};

export const generateFullMissionContent = async (chapter: string, subtopic: string, difficulty: Difficulty): Promise<{ summary: Summary, quiz: Question[] }> => {
  const cached = getCachedMission(chapter, subtopic);
  if (cached) return cached;

  // Single combined prompt to reduce API round-trip overhead and improve speed
  const prompt = `Generate a comprehensive exam-ready lesson plan and quiz for Class 8 students on the subtopic "${subtopic}" from the chapter "${chapter}". 
  1. SUMMARY: Provide 4 exam-focused bullet points and 3 key terms.
  2. QUIZ: Generate 3 high-quality EXAM LEVEL MCQ questions (Indian NCERT/Olympiad style).
  Return strictly as JSON.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: {
            type: Type.OBJECT,
            properties: {
              chapter: { type: Type.STRING },
              title: { type: Type.STRING },
              content: { type: Type.ARRAY, items: { type: Type.STRING } },
              key_terms: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["chapter", "title", "content", "key_terms"]
          },
          quiz: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correct_answer: { type: Type.STRING },
                explanation: { type: Type.STRING },
                hint: { type: Type.STRING },
                points: { type: Type.INTEGER }
              },
              required: ["question", "options", "correct_answer", "explanation", "hint"]
            }
          }
        },
        required: ["summary", "quiz"]
      }
    }
  });

  const result = JSON.parse(response.text);
  setCache(`${chapter}_${subtopic}`, result.summary, result.quiz);
  return result;
};

export const generateBriefingAudio = async (text: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ 
      parts: [{ 
        text: `Narrate this school science summary in a clear, formal, and encouraging Indian English accent: ${text}` 
      }] 
    }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' }, 
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Audio generation failed");
  return base64Audio;
};

// Legacy exports kept for compatibility but redirected to optimized flow
export const generateScienceSummary = async (chapter: string, subtopic: string) => {
  const res = await generateFullMissionContent(chapter, subtopic, 'Medium');
  return res.summary;
};

export const generateQuizSet = async (chapter: string, subtopic: string, difficulty: Difficulty) => {
  const res = await generateFullMissionContent(chapter, subtopic, difficulty);
  return res.quiz;
};
